package com.example.test_project.entities;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigInteger;

@Document(collection = "Hoster")
@Data
public class User {
    @Id
    private BigInteger id;
    private String name;
    private String prenom;
    private String cni;
    private String rib;
    private int age;

    private String category;
    private String addresse;
    private String phone_number;
    private String email;
    private String password;
    private String confirmePassword;
    private String role;
    private  String image="image path";
    private boolean validated;

    public User(BigInteger id, String name, String prenom, String cni, String rib, int age, String category, String addresse, String phone_number, String email, String password, String confirmePassword, String role, String image, boolean validated) {
        this.id = id;
        this.name = name;
        this.prenom = prenom;
        this.cni = cni;
        this.rib = rib;
        this.age = age;
        this.category = category;
        this.addresse = addresse;
        this.phone_number = phone_number;
        this.email = email;
        this.password = password;
        this.confirmePassword = confirmePassword;
        this.role = role;
        this.image = image;
        this.validated = validated;
    }

//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getCni() {
//        return cni;
//    }
//
//    public void setCni(String cni) {
//        this.cni = cni;
//    }
//
//    public String getRib() {
//        return rib;
//    }
//
//    public void setRib(String rib) {
//        this.rib = rib;
//    }
//
//    public int getAge() {
//        return age;
//    }
//
//    public void setAge(int age) {
//        this.age = age;
//    }
//
//    public String getCategory() {
//        return category;
//    }
//
//    public void setCategory(String category) {
//        this.category = category;
//    }
//
//    public String getAddresse() {
//        return addresse;
//    }
//
//    public void setAddresse(String addresse) {
//        this.addresse = addresse;
//    }
//
//    public String getPhone_number() {
//        return phone_number;
//    }
//
//    public void setPhone_number(String phone_number) {
//        this.phone_number = phone_number;
//    }
//
//    public BigInteger getId() {
//        return id;
//    }
//
//
//    public void setId(BigInteger id) {
//        this.id = id;
//    }
//
//    public String getNom() {
//        return name;
//    }
//
//    public void setNom(String nom) {
//        this.name = nom;
//    }
//
//    public String getPrenom() {
//        return category;
//    }
//
//    public void setPrenom(String prenom) {
//        this.category = prenom;
//    }
//
//    public String getAddress() {
//        return addresse;
//    }
//
//    public void setAddress(String address) {
//        this.addresse = address;
//    }
//
//    public String getTelephone() {
//        return phone_number;
//    }
//
//    public void setTelephone(String telephone) {
//        this.phone_number = telephone;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public String getConfirmePassword() {
//        return confirmePassword;
//    }
//
//    public void setConfirmePassword(String confirmePassword) {
//        this.confirmePassword = confirmePassword;
//    }
//    public String getRole() {
//        return role;
//    }
//
//    public void setRole(String role) {
//        this.role = role;
//    }
//
//    public String getImage() {
//        return image;
//    }
//
//    public void setImage(String image) {
//        this.image = image;
//    }
//
//    public boolean isValidated() {
//        return validated;
//    }
//
//    public void setValidated(boolean validated) {
//        this.validated = validated;
//    }


    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getNom() {
        return name;
    }

    public void setNom(String name) {
        this.name = name;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getCni() {
        return cni;
    }

    public void setCni(String cni) {
        this.cni = cni;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAddresse() {
        return addresse;
    }

    public void setAddresse(String addresse) {
        this.addresse = addresse;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmePassword() {
        return confirmePassword;
    }

    public void setConfirmePassword(String confirmePassword) {
        this.confirmePassword = confirmePassword;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isValidated() {
        return validated;
    }

    public void setValidated(boolean validated) {
        this.validated = validated;
    }
}
