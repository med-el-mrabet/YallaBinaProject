package com.example.test_project.reposiroty;


import com.example.test_project.entities.User;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.math.BigInteger;
import java.util.Optional;

public interface userrepository extends MongoRepository<User, ObjectId> {


    User findByEmail(String email);

    void deleteById(BigInteger id);

    Optional<User> findById(BigInteger id);
}
